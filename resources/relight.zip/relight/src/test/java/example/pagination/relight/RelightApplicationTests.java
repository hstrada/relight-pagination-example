package example.pagination.relight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelightApplicationTests {

	@Test
	void contextLoads() {
	}

}
