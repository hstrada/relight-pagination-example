package example.pagination.relight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelightApplication {

	public static void main(String[] args) {
		SpringApplication.run(RelightApplication.class, args);
	}

}
